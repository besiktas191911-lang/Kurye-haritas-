/* Kurye Harita — servis çalışanı: uygulama kabuğu + harita karoları önbelleği */
const SHELL = 'kh-shell-v1';
const TILES = 'kh-tiles-v1';
const MAX_TILES = 700;
const ASSETS = [
  './', 'index.html', 'style.css', 'app.js', 'manifest.json', 'icon.svg',
  'lib/leaflet.js', 'lib/leaflet.css',
  'lib/images/layers.png', 'lib/images/layers-2x.png',
  'lib/images/marker-icon.png', 'lib/images/marker-icon-2x.png', 'lib/images/marker-shadow.png'
];
const TILE_HOSTS = ['tile.openstreetmap.org', 'basemaps.cartocdn.com', 'server.arcgisonline.com'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(SHELL).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(ks => Promise.all(ks.filter(k => k !== SHELL && k !== TILES).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

async function trim(cache) {
  const keys = await cache.keys();
  if (keys.length > MAX_TILES) await Promise.all(keys.slice(0, keys.length - MAX_TILES).map(k => cache.delete(k)));
}

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Harita karoları: önce önbellek, yoksa ağ (ve kaydet)
  if (TILE_HOSTS.some(h => url.hostname === h || url.hostname.endsWith('.' + h))) {
    e.respondWith(caches.open(TILES).then(async cache => {
      const hit = await cache.match(req);
      if (hit) return hit;
      try {
        const res = await fetch(req);
        if (res && res.ok) { cache.put(req, res.clone()); trim(cache); }
        return res;
      } catch { return hit || Response.error(); }
    }));
    return;
  }

  // Uygulama dosyaları: önbellekten ver, arkada güncelle
  if (url.origin === location.origin) {
    e.respondWith(caches.open(SHELL).then(async cache => {
      const hit = await cache.match(req, { ignoreSearch: true });
      const net = fetch(req).then(res => { if (res && res.ok) cache.put(req, res.clone()); return res; }).catch(() => hit);
      return hit || net;
    }));
  }
  // API istekleri (rota, arama, hava…) hep ağdan
});
