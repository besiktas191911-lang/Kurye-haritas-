(() => {
'use strict';

/* =====================================================================
   Kurye Harita — Leaflet + OpenStreetMap + ücretsiz API'ler
   ===================================================================== */

/* ---------- yardımcılar ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const store = {
  get(k, d) { try { const v = localStorage.getItem('kh_' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('kh_' + k, JSON.stringify(v)); } catch { /* dolu olabilir */ } }
};
const isNative = !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
const plugin = n => (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins[n]) || null;

function hav(a, b) {
  const R = 6371000, r = Math.PI / 180;
  const dLat = (b.lat - a.lat) * r, dLng = (b.lng - a.lng) * r;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}
const fmtDist = m => m < 950 ? Math.max(10, Math.round(m / 10) * 10) + ' m' : (m / 1000).toFixed(m < 10000 ? 1 : 0) + ' km';
const fmtDur = s => s < 3600 ? Math.max(1, Math.round(s / 60)) + ' dk' : Math.floor(s / 3600) + ' sa ' + Math.round((s % 3600) / 60) + ' dk';
const fmtTime = d => new Date(d).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
const dayKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

async function fetchJson(url, opt = {}, timeout = 12000) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await fetch(url, { ...opt, signal: ctl.signal });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}

/* ---------- durum ---------- */
const defaults = {
  nav: 'google', profile: 'motor', fee: 60, cur: '₺', kmCost: 2.5, dwell: 3,
  theme: 'auto', layer: 'voyager', wake: true, autoRoute: true, cc: '90'
};
const S = {
  stops: store.get('stops', []),
  settings: { ...defaults, ...store.get('settings', {}) },
  hist: store.get('hist', {}),
  shift: store.get('shift', { active: false, since: 0 }),
  me: null, follow: true, route: null
};
const saveStops = () => store.set('stops', S.stops);
const saveSettings = () => store.set('settings', S.settings);
const saveHist = () => store.set('hist', S.hist);
const saveShift = () => store.set('shift', S.shift);
const today = () => (S.hist[dayKey()] ||= { done: [], exp: [], km: 0, ms: 0 });
const pend = () => S.stops.filter(s => !s.done);
const money = v => (Math.round(v * 100) / 100).toLocaleString('tr-TR') + ' ' + S.settings.cur;

/* ---------- toast ---------- */
let toastT;
function toast(msg, ms = 2600) {
  const el = $('#toast');
  el.textContent = msg; el.hidden = false;
  clearTimeout(toastT); toastT = setTimeout(() => { el.hidden = true; }, ms);
}

/* ---------- tema ---------- */
const mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
function applyTheme() {
  const t = S.settings.theme;
  const dark = t === 'dark' || (t === 'auto' && mq && mq.matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const m = $('meta[name=theme-color]'); if (m) m.content = dark ? '#171b22' : '#ffffff';
}
if (mq && mq.addEventListener) mq.addEventListener('change', applyTheme);
applyTheme();

/* =====================================================================
   HARİTA
   ===================================================================== */
const LAYERS = {
  voyager: { url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', opt: { subdomains: 'abcd', maxZoom: 20, attribution: '© OpenStreetMap © CARTO' }, name: 'Açık' },
  osm: { url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', opt: { maxZoom: 19, attribution: '© OpenStreetMap' }, name: 'Standart' },
  dark: { url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', opt: { subdomains: 'abcd', maxZoom: 20, attribution: '© OpenStreetMap © CARTO' }, name: 'Karanlık' },
  sat: { url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', opt: { maxZoom: 19, attribution: 'Esri, Maxar' }, name: 'Uydu' }
};
const lastPos = store.get('lastpos', null);
const map = L.map('map', {
  zoomControl: false, zoomSnap: 0.5, worldCopyJump: true,
  center: lastPos ? [lastPos.lat, lastPos.lng] : [41.0082, 28.9784],
  zoom: lastPos ? 15 : 11
});
map.attributionControl.setPrefix(false);
let baseLayer = null;
function setLayer(k, silent) {
  if (!LAYERS[k]) k = 'voyager';
  if (baseLayer) map.removeLayer(baseLayer);
  const d = LAYERS[k];
  baseLayer = L.tileLayer(d.url, { ...d.opt, crossOrigin: true }).addTo(map);
  S.settings.layer = k; saveSettings();
  const sel = $('[data-set=layer]'); if (sel) sel.value = k;
  if (!silent) toast('Harita: ' + d.name, 1400);
}
setLayer(S.settings.layer, true);

const routeLayer = L.layerGroup().addTo(map);
const stopsLayer = L.layerGroup().addTo(map);
const poiLayers = {};
let tempMarker = null;

/* kullanıcı işareti */
let meMarker = null, meCircle = null;
function updateMe() {
  if (!S.me) return;
  const ll = [S.me.lat, S.me.lng];
  if (!meMarker) {
    meMarker = L.marker(ll, {
      icon: L.divIcon({ className: '', iconSize: [26, 26], iconAnchor: [13, 13], html: '<div class="me"><div class="pulse"></div><div class="dot"></div><div class="arrow"></div></div>' }),
      zIndexOffset: 1000, interactive: false
    }).addTo(map);
    meCircle = L.circle(ll, { radius: S.me.acc || 20, weight: 1, color: '#2563eb', fillOpacity: .08, interactive: false }).addTo(map);
  } else {
    meMarker.setLatLng(ll); meCircle.setLatLng(ll); meCircle.setRadius(Math.min(S.me.acc || 20, 300));
  }
  const el = meMarker.getElement();
  const me = el && el.querySelector('.me');
  if (me) {
    const h = S.me.heading;
    if (typeof h === 'number' && !isNaN(h) && (S.me.speed || 0) > 1) {
      me.classList.add('has-heading');
      const a = me.querySelector('.arrow'); if (a) a.style.transform = `rotate(${h}deg)`;
    } else me.classList.remove('has-heading');
  }
}

/* durak işaretleri */
const numIcon = (n, cls) => L.divIcon({
  className: '', iconSize: [34, 42], iconAnchor: [17, 40], popupAnchor: [0, -36],
  html: `<div class="pin ${cls}"><span>${n}</span></div>`
});
function renderMarkers() {
  stopsLayer.clearLayers();
  const p = pend();
  p.forEach((s, i) => {
    const m = L.marker([s.lat, s.lng], { icon: numIcon(i + 1, i === 0 ? 'next' : ''), zIndexOffset: 500 - i }).addTo(stopsLayer);
    m.bindPopup(() => stopPopup(s));
  });
  S.stops.filter(s => s.done).forEach(s => {
    L.marker([s.lat, s.lng], { icon: numIcon('✔', 'done'), zIndexOffset: 0 }).addTo(stopsLayer);
  });
}
function stopPopup(s) {
  const el = document.createElement('div');
  el.className = 'pop';
  el.innerHTML = `<b>${esc(s.title)}</b><div class="pa">${esc(s.addr || '')}</div>
    <div class="prow"><button data-a="nav">🧭 Git</button><button data-a="done">✔ Teslim</button><button class="g" data-a="edit">✎</button></div>`;
  el.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    map.closePopup();
    if (b.dataset.a === 'nav') navTo(s);
    if (b.dataset.a === 'done') markDone(s.id);
    if (b.dataset.a === 'edit') openStopForm(null, s.id);
  });
  return el;
}

/* geçici nokta (arama sonucu / uzun basma) */
function clearTemp() { if (tempMarker) { map.removeLayer(tempMarker); tempMarker = null; } }
async function dropPoint(lat, lng, name, addr) {
  clearTemp();
  tempMarker = L.marker([lat, lng], {
    icon: L.divIcon({ className: '', iconSize: [34, 42], iconAnchor: [17, 40], popupAnchor: [0, -36], html: '<div class="pin tmp"><span>＋</span></div>' })
  }).addTo(map);
  const el = document.createElement('div');
  el.className = 'pop';
  const render = () => {
    el.innerHTML = `<b>${esc(name || 'Seçilen nokta')}</b><div class="pa">${esc(addr || 'Adres aranıyor…')}</div>
      <div class="prow"><button data-a="add">➕ Durak ekle</button><button class="g" data-a="nav">🧭 Git</button></div>`;
  };
  render();
  el.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.a === 'add') { map.closePopup(); openStopForm({ lat, lng, title: name || (addr || '').split(',')[0] || 'Yeni durak', addr: addr || '' }); }
    if (b.dataset.a === 'nav') navTo({ lat, lng });
  });
  tempMarker.bindPopup(el).openPopup();
  if (!addr) {
    addr = await reverse(lat, lng);
    if (!name) name = addr.split(',')[0];
    render();
  }
}
map.on('contextmenu', e => dropPoint(e.latlng.lat, e.latlng.lng));
map.on('dragstart', () => { if (S.follow) { S.follow = false; $('#btnLocate').classList.remove('on'); } });

/* =====================================================================
   KONUM (GPS)
   ===================================================================== */
let gpsFirst = true, gpsErrShown = false, lastSave = 0, lastWxPos = null, lastWxT = 0, nearToasted = null;
async function startGPS() {
  const geo = plugin('Geolocation');
  try {
    if (geo) {
      try { await geo.requestPermissions(); } catch { /* izin reddedildi */ }
      await geo.watchPosition({ enableHighAccuracy: true, timeout: 20000, maximumAge: 2000 }, (pos, err) => {
        if (pos) onPos(pos); else if (err) onGpsErr(err);
      });
    } else if (navigator.geolocation) {
      navigator.geolocation.watchPosition(onPos, onGpsErr, { enableHighAccuracy: true, maximumAge: 2000, timeout: 20000 });
    } else toast('Bu cihazda konum desteği yok');
  } catch (e) { onGpsErr(e); }
}
function onGpsErr() {
  if (gpsErrShown) return;
  gpsErrShown = true;
  toast('Konum alınamıyor. Konum iznini ve GPS\'i kontrol et.', 4000);
}
function onPos(p) {
  const c = p.coords; if (!c) return;
  gpsErrShown = false;
  const prev = S.me;
  S.me = { lat: c.latitude, lng: c.longitude, acc: c.accuracy, speed: c.speed, heading: c.heading, t: p.timestamp || Date.now() };
  updateMe();

  if (gpsFirst) {
    gpsFirst = false;
    map.setView([S.me.lat, S.me.lng], Math.max(map.getZoom(), 16));
    loadWeather(); if (pend().length) refreshRoute(); else renderStops();
  } else if (S.follow) map.panTo([S.me.lat, S.me.lng], { animate: true, duration: .6 });

  const kmh = Math.round((c.speed || 0) * 3.6);
  const sp = $('#speed'); sp.textContent = kmh + ' km/s'; sp.classList.toggle('show', kmh >= 2);

  if (S.shift.active && prev) addDistance(prev, S.me);
  if (Date.now() - lastSave > 8000) { lastSave = Date.now(); store.set('lastpos', { lat: S.me.lat, lng: S.me.lng }); saveHist(); }

  if (!lastWxPos || hav(lastWxPos, S.me) > 8000 || Date.now() - lastWxT > 25 * 60000) loadWeather();

  const n = pend()[0];
  if (n) {
    const d = hav(S.me, n);
    if (d < 40 && nearToasted !== n.id) { nearToasted = n.id; toast('📍 Durağa yaklaştın: ' + n.title, 3500); if (navigator.vibrate) navigator.vibrate(200); }
    if (d > 120 && nearToasted === n.id) nearToasted = null;
    if (!S.route) renderNext();
  }
}
function addDistance(a, b) {
  const d = hav(a, b), dt = (b.t - a.t) / 1000;
  if (b.acc > 40 || d < 6 || d > 600 || dt <= 0 || d / dt > 45) return;
  today().km += d;
}
function locateMe() {
  S.follow = true; $('#btnLocate').classList.add('on');
  if (S.me) map.setView([S.me.lat, S.me.lng], Math.max(map.getZoom(), 16), { animate: true });
  else toast('Konum bekleniyor…');
}

/* ekranı açık tut */
let wl = null;
async function wakeOn() {
  try {
    if (S.settings.wake && 'wakeLock' in navigator && !wl) {
      wl = await navigator.wakeLock.request('screen');
      wl.addEventListener('release', () => { wl = null; });
    }
  } catch { /* desteklenmiyor */ }
}
function wakeOff() { try { if (wl) wl.release(); } catch { /* */ } wl = null; }
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') wakeOn(); });

/* =====================================================================
   ARAMA (Nominatim → Photon yedek)
   ===================================================================== */
function shortAddr(r) {
  const a = r && r.address; if (!a) return (r && r.display_name) || '';
  const road = [a.road || a.pedestrian || a.footway || a.neighbourhood, a.house_number].filter(Boolean).join(' ');
  const area = a.suburb || a.quarter || a.city_district || a.town || a.village || '';
  const city = a.city || a.province || a.state || '';
  return [road, area, city].filter(Boolean).join(', ') || r.display_name;
}
async function geocode(q, bias) {
  const c = bias || map.getCenter();
  try {
    const p = new URLSearchParams({
      format: 'jsonv2', q, limit: '6', addressdetails: '1', 'accept-language': 'tr',
      viewbox: `${c.lng - 0.4},${c.lat + 0.3},${c.lng + 0.4},${c.lat - 0.3}`, bounded: '0'
    });
    const r = await fetchJson('https://nominatim.openstreetmap.org/search?' + p);
    if (r.length) return r.map(x => ({ lat: +x.lat, lng: +x.lon, name: x.name || (x.display_name || '').split(',')[0], addr: shortAddr(x) || x.display_name }));
  } catch { /* yedeğe geç */ }
  try {
    const r = await fetchJson(`https://photon.komoot.io/api/?q=${encodeURIComponent(q)}&limit=6&lat=${c.lat}&lon=${c.lng}`);
    return (r.features || []).map(f => {
      const p = f.properties || {};
      return {
        lat: f.geometry.coordinates[1], lng: f.geometry.coordinates[0],
        name: p.name || p.street || 'Konum',
        addr: [p.street && (p.street + (p.housenumber ? ' ' + p.housenumber : '')), p.district, p.city || p.state].filter(Boolean).join(', ') || p.name || ''
      };
    });
  } catch { return []; }
}
async function reverse(lat, lng) {
  try {
    const r = await fetchJson(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&zoom=18&accept-language=tr&lat=${lat}&lon=${lng}`);
    return shortAddr(r) || `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
  } catch { return `${lat.toFixed(5)}, ${lng.toFixed(5)}`; }
}
const COORD_RE = /(-?\d{1,3}\.\d+)\s*[,;\s]\s*(-?\d{1,3}\.\d+)/;

const qEl = $('#q'), resEl = $('#results'), qClear = $('#qClear');
let qTimer, qToken = 0;
qEl.addEventListener('input', () => {
  const v = qEl.value.trim();
  qClear.hidden = !v;
  clearTimeout(qTimer);
  if (v.length < 3) { resEl.hidden = true; return; }
  qTimer = setTimeout(() => runSearch(v), 700);
});
qEl.addEventListener('keydown', e => { if (e.key === 'Enter') { clearTimeout(qTimer); const v = qEl.value.trim(); if (v.length >= 2) runSearch(v); qEl.blur(); } });
qClear.addEventListener('click', () => { qEl.value = ''; qClear.hidden = true; resEl.hidden = true; clearTemp(); });
async function runSearch(v) {
  const tok = ++qToken;
  resEl.hidden = false; resEl.innerHTML = '<li class="rn">Aranıyor…</li>';
  const m = v.match(COORD_RE);
  let list;
  if (m) list = [{ lat: +m[1], lng: +m[2], name: 'Koordinat', addr: `${m[1]}, ${m[2]}` }];
  else list = await geocode(v);
  if (tok !== qToken) return;
  if (!list.length) { resEl.innerHTML = '<li class="rn">Sonuç bulunamadı. Mahalle/ilçe ekleyerek dene.</li>'; return; }
  resEl.innerHTML = list.map((r, i) => `<li data-i="${i}"><div class="rt">${esc(r.name)}</div><div class="ra">${esc(r.addr)}</div></li>`).join('');
  resEl.onclick = e => {
    const li = e.target.closest('li[data-i]'); if (!li) return;
    const r = list[+li.dataset.i];
    resEl.hidden = true;
    S.follow = false; $('#btnLocate').classList.remove('on');
    map.setView([r.lat, r.lng], 17);
    dropPoint(r.lat, r.lng, r.name, r.addr);
  };
}
document.addEventListener('click', e => { if (!e.target.closest('#topbar')) resEl.hidden = true; });

/* =====================================================================
   YAKINDAKİ YERLER (Overpass)
   ===================================================================== */
const POI = {
  fuel: { ico: '⛽', q: '["amenity"="fuel"]', name: 'Benzinlik' },
  repair: { ico: '🔧', q: '["shop"~"^(motorcycle_repair|car_repair|motorcycle|bicycle|tyres)$"]', name: 'Tamirci' },
  wc: { ico: '🚻', q: '["amenity"="toilets"]', name: 'Tuvalet' },
  food: { ico: '🍽️', q: '["amenity"~"^(restaurant|fast_food|cafe)$"]', name: 'Yemek' },
  pharm: { ico: '💊', q: '["amenity"="pharmacy"]', name: 'Eczane' },
  atm: { ico: '🏧', q: '["amenity"~"^(atm|bank)$"]', name: 'ATM / Banka' },
  ev: { ico: '🔌', q: '["amenity"="charging_station"]', name: 'Şarj istasyonu' }
};
const OVP = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter'];
async function overpass(q) {
  for (const u of OVP) {
    try {
      const r = await fetchJson(u, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'data=' + encodeURIComponent(q) }, 22000);
      return r.elements || [];
    } catch { /* sonraki sunucu */ }
  }
  throw new Error('overpass');
}
async function togglePoi(key, btn) {
  if (poiLayers[key]) { map.removeLayer(poiLayers[key]); delete poiLayers[key]; btn.classList.remove('on'); return; }
  const c = S.me ? { lat: S.me.lat, lng: S.me.lng } : map.getCenter();
  const cfg = POI[key];
  btn.classList.add('load');
  try {
    const els = await overpass(`[out:json][timeout:20];nwr${cfg.q}(around:2500,${c.lat},${c.lng});out center 60;`);
    const lg = L.layerGroup();
    els.forEach(e => {
      const lat = e.lat ?? (e.center && e.center.lat), lng = e.lon ?? (e.center && e.center.lon);
      if (lat == null) return;
      const t = e.tags || {};
      const name = t.name || t.brand || t.operator || cfg.name;
      const m = L.marker([lat, lng], { icon: L.divIcon({ className: '', iconSize: [30, 30], iconAnchor: [15, 15], html: `<div class="poi">${cfg.ico}</div>` }) }).addTo(lg);
      m.bindPopup(() => {
        const el = document.createElement('div'); el.className = 'pop';
        const extra = [t.opening_hours && '🕒 ' + t.opening_hours, t.phone && '📞 ' + t.phone].filter(Boolean).join('<br>');
        el.innerHTML = `<b>${esc(name)}</b><div class="pa">${esc(cfg.name)}${S.me ? ' · ' + fmtDist(hav(S.me, { lat, lng })) : ''}${extra ? '<br>' + esc(extra).replace(/&lt;br&gt;/g, '<br>') : ''}</div>
          <div class="prow"><button data-a="nav">🧭 Git</button><button class="g" data-a="add">➕ Durak</button></div>`;
        el.addEventListener('click', ev => {
          const b = ev.target.closest('button'); if (!b) return;
          map.closePopup();
          if (b.dataset.a === 'nav') navTo({ lat, lng });
          if (b.dataset.a === 'add') openStopForm({ lat, lng, title: name, addr: cfg.name });
        });
        return el;
      });
    });
    lg.addTo(map); poiLayers[key] = lg; btn.classList.add('on');
    toast(els.length ? `${els.length} ${cfg.name.toLowerCase()} bulundu` : `Yakında ${cfg.name.toLowerCase()} bulunamadı`);
  } catch { toast('Yakındaki yerler yüklenemedi (internet?)'); }
  btn.classList.remove('load');
}
$('#chips').addEventListener('click', e => { const b = e.target.closest('.chip'); if (b) togglePoi(b.dataset.poi, b); });

/* =====================================================================
   HAVA DURUMU (Open-Meteo)
   ===================================================================== */
const WMO = (c) => c === 0 ? ['☀️', 'Açık'] : c <= 2 ? ['🌤️', 'Az bulutlu'] : c === 3 ? ['☁️', 'Bulutlu'] : c <= 48 ? ['🌫️', 'Sisli'] :
  c <= 57 ? ['🌦️', 'Çiseleme'] : c <= 67 ? ['🌧️', 'Yağmurlu'] : c <= 77 ? ['❄️', 'Karlı'] : c <= 82 ? ['🌧️', 'Sağanak'] : c <= 86 ? ['🌨️', 'Kar sağanağı'] : ['⛈️', 'Fırtına'];
let wxInfo = '';
async function loadWeather() {
  const c = S.me || map.getCenter();
  lastWxPos = { lat: c.lat, lng: c.lng }; lastWxT = Date.now();
  try {
    const u = `https://api.open-meteo.com/v1/forecast?latitude=${c.lat.toFixed(3)}&longitude=${c.lng.toFixed(3)}` +
      '&current=temperature_2m,apparent_temperature,weather_code,wind_gusts_10m,precipitation' +
      '&hourly=precipitation_probability&daily=sunset&forecast_days=2&timezone=auto';
    const w = await fetchJson(u);
    const cur = w.current, [ico, label] = WMO(cur.weather_code);
    let maxP = 0;
    const hrs = (w.hourly && w.hourly.time) || [];
    const nowH = cur.time.slice(0, 13);
    const i0 = hrs.findIndex(t => t.slice(0, 13) >= nowH);
    if (i0 >= 0) for (let i = i0; i < Math.min(i0 + 3, hrs.length); i++) maxP = Math.max(maxP, w.hourly.precipitation_probability[i] || 0);
    const alerts = [];
    if (cur.weather_code >= 95) alerts.push('⛈️ Fırtına uyarısı');
    else if (cur.precipitation > 0 || maxP >= 50) alerts.push(`☔ Yağış ihtimali %${Math.max(maxP, 50)}`);
    if (cur.wind_gusts_10m >= 40) alerts.push(`💨 Rüzgâr ${Math.round(cur.wind_gusts_10m)} km/s`);
    if (cur.temperature_2m <= 3) alerts.push('🧊 Buzlanma riski');
    if (cur.temperature_2m >= 35) alerts.push('🥵 Aşırı sıcak, su iç');
    const sunset = w.daily && w.daily.sunset && w.daily.sunset[0] ? w.daily.sunset[0].slice(11, 16) : '';
    const el = $('#wx');
    el.textContent = `${ico} ${Math.round(cur.temperature_2m)}°` + (alerts.length ? ' · ' + alerts[0] : ' · ' + label);
    el.classList.toggle('warn', alerts.length > 0);
    wxInfo = `${label}, hissedilen ${Math.round(cur.apparent_temperature)}°` + (sunset ? ` · gün batımı ${sunset}` : '') + (alerts.length ? ' · ' + alerts.join(' · ') : '');
  } catch { $('#wx').textContent = '🌡️ Hava alınamadı'; }
}
$('#wx').addEventListener('click', () => { if (wxInfo) toast(wxInfo, 5000); else loadWeather(); });

/* =====================================================================
   DURAKLAR
   ===================================================================== */
function openModal(html, mount) {
  $('#modalCard').innerHTML = html;
  $('#modal').hidden = false;
  if (mount) mount($('#modalCard'));
}
function closeModal() { $('#modal').hidden = true; $('#modalCard').innerHTML = ''; }
$('.mback').addEventListener('click', closeModal);

function openStopForm(data, id) {
  const ex = id ? S.stops.find(s => s.id === id) : null;
  const v = ex ? { ...ex } : { phone: '', note: '', fee: S.settings.fee, ...data };
  openModal(`
    <h3>${ex ? 'Durağı düzenle' : 'Yeni durak'}</h3>
    <div class="form">
      <label>Müşteri / başlık<input type="text" id="f-title" value="${esc(v.title)}" placeholder="Örn. Ahmet Bey"></label>
      <label>Adres<input type="text" id="f-addr" value="${esc(v.addr)}"></label>
      <div class="row2">
        <label>Telefon<input type="tel" id="f-phone" value="${esc(v.phone)}" placeholder="05xx xxx xx xx"></label>
        <label>Ücret (${esc(S.settings.cur)})<input type="number" inputmode="decimal" id="f-fee" value="${esc(v.fee)}" step="0.5" min="0"></label>
      </div>
      <label>Not (kat, daire, kapı kodu…)<input type="text" id="f-note" value="${esc(v.note)}"></label>
    </div>
    <div class="mbtns">
      ${ex ? '<button class="btn danger" id="f-del" style="margin:0">Sil</button>' : '<button class="btn ghost" id="f-cancel">İptal</button>'}
      <button class="btn" id="f-save">Kaydet</button>
    </div>`, c => {
    const get = k => $('#f-' + k, c).value.trim();
    $('#f-save', c).onclick = () => {
      const o = { title: get('title') || 'Durak', addr: get('addr'), phone: get('phone'), note: get('note'), fee: parseFloat(get('fee')) || 0 };
      if (ex) Object.assign(ex, o);
      else S.stops.push({ id: uid(), lat: v.lat, lng: v.lng, done: false, ...o });
      clearTemp(); closeModal(); stopsChanged();
      toast(ex ? 'Durak güncellendi' : '✔ Durak eklendi');
    };
    if ($('#f-del', c)) $('#f-del', c).onclick = () => { S.stops = S.stops.filter(s => s.id !== id); closeModal(); stopsChanged(); toast('Durak silindi'); };
    if ($('#f-cancel', c)) $('#f-cancel', c).onclick = closeModal;
  });
}

function stopsChanged(route = true) {
  saveStops(); renderStops();
  if (route && S.settings.autoRoute) scheduleRoute(); else if (!pend().length) clearRoute();
}
function markDone(id) {
  const s = S.stops.find(x => x.id === id); if (!s) return;
  s.done = !s.done;
  const h = today();
  if (s.done) { s.doneAt = Date.now(); h.done.push({ id: s.id, title: s.title, fee: +s.fee || 0, t: s.doneAt }); toast('✔ Teslim edildi · +' + money(+s.fee || 0)); if (navigator.vibrate) navigator.vibrate(60); }
  else { h.done = h.done.filter(d => d.id !== s.id); toast('Teslim geri alındı'); }
  saveHist();
  // tamamlananı listenin sonuna taşı
  S.stops = [...S.stops.filter(x => !x.done), ...S.stops.filter(x => x.done)];
  stopsChanged(); renderEarn();
}
function moveStop(id, dir) {
  const p = pend(); const i = p.findIndex(s => s.id === id); const j = i + dir;
  if (i < 0 || j < 0 || j >= p.length) return;
  [p[i], p[j]] = [p[j], p[i]];
  S.stops = [...p, ...S.stops.filter(s => s.done)];
  stopsChanged();
}

/* navigasyon / arama / mesaj */
function navTo(s) {
  const { lat, lng } = s, nav = S.settings.nav, prof = S.settings.profile;
  if (nav === 'google') {
    if (isNative) location.href = `google.navigation:q=${lat},${lng}&mode=${prof === 'foot' ? 'w' : prof === 'bike' ? 'b' : 'l'}`;
    else window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=${prof === 'foot' ? 'walking' : prof === 'bike' ? 'bicycling' : 'driving'}`, '_blank');
  } else if (nav === 'yandex') {
    if (isNative) location.href = `yandexnavi://build_route_on_map?lat_to=${lat}&lon_to=${lng}`;
    else window.open(`https://yandex.com.tr/harita/?rtext=~${lat},${lng}&rtt=auto`, '_blank');
  } else if (nav === 'waze') window.open(`https://waze.com/ul?ll=${lat},${lng}&navigate=yes`, '_blank');
  else location.href = `geo:${lat},${lng}?q=${lat},${lng}`;
}
function phoneDigits(p) {
  let d = String(p || '').replace(/\D/g, '');
  if (d.startsWith('00')) d = d.slice(2);
  else if (d.startsWith('0')) d = S.settings.cc + d.slice(1);
  else if (d.length === 10) d = S.settings.cc + d;
  return d;
}
function callStop(s) { if (!s.phone) return toast('Telefon kayıtlı değil'); location.href = 'tel:' + s.phone.replace(/[^\d+]/g, ''); }
function waStop(s) { if (!s.phone) return toast('Telefon kayıtlı değil'); window.open('https://wa.me/' + phoneDigits(s.phone), '_blank'); }
function openAllGoogle() {
  const p = pend(); if (!p.length) return toast('Bekleyen durak yok');
  const list = p.slice(0, 10); // Google ~9 ara nokta destekler
  const dest = list[list.length - 1], wp = list.slice(0, -1).map(s => `${s.lat},${s.lng}`).join('|');
  const prof = S.settings.profile;
  let u = `https://www.google.com/maps/dir/?api=1&destination=${dest.lat},${dest.lng}&travelmode=${prof === 'foot' ? 'walking' : prof === 'bike' ? 'bicycling' : 'driving'}`;
  if (S.me) u += `&origin=${S.me.lat},${S.me.lng}`;
  if (wp) u += `&waypoints=${encodeURIComponent(wp)}`;
  window.open(u, '_blank');
  if (p.length > 10) toast('Google en fazla ~10 durak alır; ilk 10 açıldı', 4000);
}

/* ---------- render ---------- */
function legFor(s) {
  const r = S.route; if (!r || !r.by[s.id]) return null;
  const l = r.by[s.id]; return { d: l.d, t: l.t, eta: r.at + l.cum * 1000 };
}
function stopItem(s, n, next) {
  const leg = !s.done && legFor(s);
  const dStr = !s.done ? (leg ? fmtDist(leg.d) : (S.me ? '~' + fmtDist(hav(S.me, s)) : '')) : '';
  const meta = [
    dStr && `📏 <b>${dStr}</b>`,
    leg && `🕒 <b>${fmtTime(leg.eta)}</b>`,
    s.fee ? `💵 ${esc(money(+s.fee))}` : '',
    s.phone ? `📞 ${esc(s.phone)}` : ''
  ].filter(Boolean).join('');
  return `<li class="stop ${next ? 'next open' : ''} ${s.done ? 'isdone' : ''}" data-id="${s.id}">
    <div class="num">${s.done ? '✔' : n}</div>
    <div class="info">
      <div class="t">${esc(s.title)}</div>
      ${s.addr ? `<div class="a">${esc(s.addr)}</div>` : ''}
      <div class="m">${meta}</div>
      ${s.note ? `<div class="note">📝 ${esc(s.note)}</div>` : ''}
      <div class="acts">
        ${s.done ? `<button data-act="done">↩ Geri al</button>` : `
        <button class="go" data-act="nav">🧭 Git</button>
        <button class="ok" data-act="done">✔ Teslim</button>
        <button data-act="focus">🎯</button>
        ${s.phone ? '<button data-act="call">📞</button><button data-act="wa">💬</button>' : ''}
        <button data-act="up">▲</button><button data-act="down">▼</button>`}
        <button data-act="edit">✎</button>
        <button class="del" data-act="del">🗑️</button>
      </div>
    </div></li>`;
}
function renderStops() {
  const p = pend(), done = S.stops.filter(s => s.done);
  $('#stopList').innerHTML = p.length ? p.map((s, i) => stopItem(s, i + 1, i === 0)).join('') :
    `<li class="empty"><b>Henüz durak yok</b>Yukarıdan adres ara, haritaya uzun bas<br>veya ＋ ile hedefi seç. "Toplu ekle" ile birden çok adres yapıştırabilirsin.</li>`;
  $('#doneBox').hidden = !done.length;
  $('#doneCount').textContent = done.length;
  $('#doneList').innerHTML = done.map((s, i) => stopItem(s, i + 1, false)).join('');
  const sum = $('#summary');
  const tot = S.route && S.route.ids.join() === p.map(s => s.id).join() ? S.route : null;
  const fee = p.reduce((a, s) => a + (+s.fee || 0), 0);
  sum.innerHTML = p.length ? `
    <div class="sc"><b>${p.length}</b><small>bekleyen</small></div>
    <div class="sc"><b>${tot ? fmtDist(tot.dist) : '—'}</b><small>toplam yol</small></div>
    <div class="sc"><b>${tot ? fmtDur(tot.dur + p.length * S.settings.dwell * 60) : '—'}</b><small>tahmini süre</small></div>
    <div class="sc"><b>${esc(money(fee))}</b><small>beklenen kazanç</small></div>` : '';
  renderNext(); renderMarkers();
}
function renderNext() {
  const n = pend()[0], el = $('#nextbar');
  if (!n) { el.innerHTML = '<div class="nb-info"><div class="nb-t">Bekleyen durak yok</div><div class="nb-s">Adres ara veya haritaya uzun basarak ekle</div></div>'; return; }
  const leg = legFor(n);
  const sub = leg ? `${fmtDist(leg.d)} · ${fmtDur(leg.t)} · ${fmtTime(leg.eta)}` : (S.me ? '~' + fmtDist(hav(S.me, n)) + ' kuş uçuşu' : (n.addr || ''));
  el.innerHTML = `<div class="nb-num">1</div>
    <div class="nb-info"><div class="nb-t">${esc(n.title)}</div><div class="nb-s">${esc(sub)}</div></div>
    <button class="nb-go" data-a="nav" aria-label="Git">🧭</button><button class="nb-ok" data-a="done" aria-label="Teslim">✔</button>`;
}
$('#nextbar').addEventListener('click', e => {
  const b = e.target.closest('button'); const n = pend()[0]; if (!b || !n) return;
  if (b.dataset.a === 'nav') navTo(n); if (b.dataset.a === 'done') markDone(n.id);
});
function stopListClick(e) {
  const li = e.target.closest('.stop'); if (!li) return;
  const s = S.stops.find(x => x.id === li.dataset.id); if (!s) return;
  const b = e.target.closest('button');
  if (!b) { li.classList.toggle('open'); return; }
  switch (b.dataset.act) {
    case 'nav': navTo(s); break;
    case 'done': markDone(s.id); break;
    case 'call': callStop(s); break;
    case 'wa': waStop(s); break;
    case 'edit': openStopForm(null, s.id); break;
    case 'up': moveStop(s.id, -1); break;
    case 'down': moveStop(s.id, 1); break;
    case 'focus': S.follow = false; $('#btnLocate').classList.remove('on'); setSheet(SNAP()[0]); map.setView([s.lat, s.lng], 17); break;
    case 'del': if (confirm('Bu durak silinsin mi?')) { S.stops = S.stops.filter(x => x.id !== s.id); stopsChanged(); } break;
  }
}
$('#stopList').addEventListener('click', stopListClick);
$('#doneList').addEventListener('click', stopListClick);
$('#btnClearDone').addEventListener('click', () => { S.stops = S.stops.filter(s => !s.done); stopsChanged(false); });

/* =====================================================================
   ROTA: optimizasyon (en yakın komşu + 2-opt) ve OSRM
   ===================================================================== */
function optimizeOrder() {
  const p = pend();
  if (p.length < 2) return toast('Optimize için en az 2 bekleyen durak gerekli');
  const start = S.me ? { lat: S.me.lat, lng: S.me.lng } : { lat: p[0].lat, lng: p[0].lng };
  const rem = p.slice(), order = []; let cur = start;
  while (rem.length) {
    let bi = 0, bd = Infinity;
    rem.forEach((s, i) => { const d = hav(cur, s); if (d < bd) { bd = d; bi = i; } });
    cur = rem.splice(bi, 1)[0]; order.push(cur);
  }
  const pts = [start, ...order]; const n = pts.length - 1;
  const D = (a, b) => hav(a, b);
  let improved = true, guard = 0;
  while (improved && guard++ < 60) {
    improved = false;
    for (let i = 1; i < n; i++) for (let j = i + 1; j <= n; j++) {
      const before = D(pts[i - 1], pts[i]) + (j < n ? D(pts[j], pts[j + 1]) : 0);
      const after = D(pts[i - 1], pts[j]) + (j < n ? D(pts[i], pts[j + 1]) : 0);
      if (after < before - 1) { pts.splice(i, j - i + 1, ...pts.slice(i, j + 1).reverse()); improved = true; }
    }
  }
  const oldLen = pathLen([start, ...p]), newLen = pathLen(pts);
  S.stops = [...pts.slice(1), ...S.stops.filter(s => s.done)];
  stopsChanged();
  toast(newLen < oldLen ? `🔀 Rota kısaldı: ${fmtDist(oldLen)} → ${fmtDist(newLen)}` : '🔀 Sıra zaten verimli');
}
const pathLen = pts => pts.reduce((a, p, i) => i ? a + hav(pts[i - 1], p) : 0, 0);

let routeTimer, routeTok = 0;
function scheduleRoute() { clearTimeout(routeTimer); routeTimer = setTimeout(refreshRoute, 700); }
function clearRoute() { routeLayer.clearLayers(); S.route = null; }
async function refreshRoute() {
  const p = pend();
  if (!p.length) { clearRoute(); renderStops(); return; }
  const pts = [...(S.me ? [S.me] : []), ...p];
  if (pts.length < 2) { clearRoute(); renderStops(); return; }
  const tok = ++routeTok;
  const svc = { motor: 'routed-car', bike: 'routed-bike', foot: 'routed-foot' }[S.settings.profile] || 'routed-car';
  const coords = pts.slice(0, 40).map(s => `${(+s.lng).toFixed(6)},${(+s.lat).toFixed(6)}`).join(';');
  try {
    const r = await fetchJson(`https://routing.openstreetmap.de/${svc}/route/v1/driving/${coords}?overview=full&geometries=geojson&steps=false`, {}, 15000);
    if (tok !== routeTok) return;
    if (!r.routes || !r.routes[0]) throw new Error('rota yok');
    const rt = r.routes[0];
    routeLayer.clearLayers();
    const ll = rt.geometry.coordinates.map(c => [c[1], c[0]]);
    L.polyline(ll, { color: '#fff', weight: 10, opacity: .95, lineCap: 'round', lineJoin: 'round' }).addTo(routeLayer);
    L.polyline(ll, { color: '#ff6b1a', weight: 6, opacity: 1, lineCap: 'round', lineJoin: 'round' }).addTo(routeLayer);
    const by = {}; let cum = 0; const ids = [];
    const off = S.me ? 0 : -1; // konum yoksa ilk durak başlangıç
    p.forEach((s, i) => {
      const leg = rt.legs[i + off];
      if (leg) { cum += leg.duration; by[s.id] = { d: leg.distance, t: leg.duration, cum }; cum += S.settings.dwell * 60; }
      else by[s.id] = { d: 0, t: 0, cum };
      ids.push(s.id);
    });
    S.route = { dist: rt.distance, dur: rt.duration, at: Date.now(), by, ids };
  } catch {
    if (tok !== routeTok) return;
    routeLayer.clearLayers();
    L.polyline(pts.map(s => [s.lat, s.lng]), { color: '#ff6b1a', weight: 5, dashArray: '8 10', opacity: .9 }).addTo(routeLayer);
    const by = {}; let cum = 0; const ids = []; let dist = 0;
    const speed = { motor: 8, bike: 4.5, foot: 1.3 }[S.settings.profile] || 8; // m/s, kuş uçuşu x1.35
    p.forEach((s, i) => {
      const a = i === 0 ? (S.me || s) : p[i - 1];
      const d = hav(a, s) * 1.35, t = d / speed; dist += d; cum += t; by[s.id] = { d, t, cum }; cum += S.settings.dwell * 60; ids.push(s.id);
    });
    S.route = { dist, dur: cum, at: Date.now(), by, ids };
    toast('Rota servisine ulaşılamadı; tahmini (kuş uçuşu) gösteriliyor', 3500);
  }
  renderStops();
}
function fitAll() {
  const pts = pend().map(s => [s.lat, s.lng]); if (S.me) pts.push([S.me.lat, S.me.lng]);
  if (!pts.length) return locateMe();
  S.follow = false; $('#btnLocate').classList.remove('on');
  map.fitBounds(L.latLngBounds(pts), { paddingTopLeft: [40, 190], paddingBottomRight: [40, sheetH + 40], maxZoom: 17 });
}

/* =====================================================================
   TOPLU EKLE
   ===================================================================== */
function openBulk() {
  openModal(`<h3>Toplu adres ekle</h3>
    <div class="form">
      <label>Her satıra bir adres (veya "41.0123, 28.9876" koordinatı)
        <textarea id="b-text" placeholder="Bağdat Cd. 120, Kadıköy&#10;İstiklal Cd. 55, Beyoğlu&#10;41.0369, 28.9850"></textarea></label>
      <p class="hint">Adresler tek tek aranır (saniyede 1 — servis kuralı). Şehir/ilçe yazarsan daha doğru bulur.</p>
      <div id="b-status" class="hint"></div>
    </div>
    <div class="mbtns"><button class="btn ghost" id="b-cancel">İptal</button><button class="btn" id="b-go">Ekle</button></div>`, c => {
    $('#b-cancel', c).onclick = closeModal;
    $('#b-go', c).onclick = async () => {
      const lines = $('#b-text', c).value.split('\n').map(l => l.trim()).filter(Boolean).slice(0, 30);
      if (!lines.length) return;
      const btn = $('#b-go', c); btn.disabled = true;
      const st = $('#b-status', c); let ok = 0; const fail = [];
      for (let i = 0; i < lines.length; i++) {
        st.textContent = `Aranıyor ${i + 1}/${lines.length}: ${lines[i]}`;
        const m = lines[i].match(COORD_RE); let hit = null;
        if (m) hit = { lat: +m[1], lng: +m[2], name: 'Koordinat', addr: lines[i] };
        else { const r = await geocode(lines[i], S.me || undefined); hit = r[0]; await sleep(1100); }
        if (hit) { S.stops.push({ id: uid(), lat: hit.lat, lng: hit.lng, title: lines[i].slice(0, 40), addr: hit.addr, phone: '', note: '', fee: S.settings.fee, done: false }); ok++; }
        else fail.push(lines[i]);
      }
      closeModal(); stopsChanged();
      toast(`${ok} durak eklendi` + (fail.length ? `, ${fail.length} adres bulunamadı` : ''), 4000);
      if (ok) fitAll();
    };
  });
}

/* =====================================================================
   KAZANÇ
   ===================================================================== */
const sumFee = a => a.reduce((t, x) => t + (+x.fee || 0), 0);
function shiftMs() { return today().ms + (S.shift.active ? Date.now() - S.shift.since : 0); }
function fmtHM(ms) { const m = Math.floor(ms / 60000); return Math.floor(m / 60) + ' sa ' + String(m % 60).padStart(2, '0') + ' dk'; }
function renderEarn() {
  const h = today(), gross = sumFee(h.done), exp = h.exp.reduce((a, x) => a + (+x.amt || 0), 0);
  const km = h.km / 1000, fuel = km * S.settings.kmCost, net = gross - exp - fuel, ms = shiftMs();
  const perH = ms > 600000 ? gross / (ms / 3600000) : 0;
  const days = []; for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); const k = dayKey(d); const hh = S.hist[k]; days.push({ k, d, v: hh ? sumFee(hh.done) : 0 }); }
  const max = Math.max(1, ...days.map(x => x.v));
  $('#p-earn').innerHTML = `
    <div class="cards">
      <div class="card2 big"><small>Bugünkü net kazanç (tahmini)</small><b>${esc(money(net))}</b></div>
      <div class="card2"><small>Teslimat</small><b>${h.done.length}</b></div>
      <div class="card2"><small>Brüt kazanç</small><b>${esc(money(gross))}</b></div>
      <div class="card2"><small>Mesafe (GPS)</small><b>${km.toFixed(1)} km</b></div>
      <div class="card2"><small>Vardiya süresi</small><b id="shiftTime">${fmtHM(ms)}</b></div>
      <div class="card2"><small>Saatlik kazanç</small><b>${perH ? esc(money(perH)) : '—'}</b></div>
      <div class="card2"><small>Yakıt/bakım (${S.settings.kmCost}/km)</small><b>${esc(money(fuel))}</b></div>
    </div>
    <button class="shiftbtn ${S.shift.active ? 'stop' : 'start'}" id="btnShift">${S.shift.active ? '⏹ Vardiyayı bitir' : '▶ Vardiyayı başlat (km ve süre sayılır)'}</button>

    <div class="sect">⚡ Hızlı teslimat ekle</div>
    <div class="inline"><input id="qf-fee" type="number" inputmode="decimal" placeholder="Ücret" value="${esc(S.settings.fee)}"><button class="btn" id="btnQuick">+1 teslimat</button></div>

    <div class="sect">⛽ Gider ekle (yakıt, yemek…)</div>
    <div class="inline"><input id="ex-amt" type="number" inputmode="decimal" placeholder="Tutar"><input id="ex-note" type="text" placeholder="Not"><button class="btn" id="btnExp">Ekle</button></div>
    ${h.exp.length ? `<p class="hint">Bugünkü giderler: ${h.exp.map(x => esc(money(+x.amt)) + (x.note ? ' (' + esc(x.note) + ')' : '')).join(', ')}</p>` : ''}

    <div class="sect">📊 Son 7 gün (brüt)</div>
    <div class="bars">${days.map((x, i) => `<div class="bc ${i === 6 ? 'today' : ''}"><div class="bv">${x.v ? Math.round(x.v) : ''}</div><div class="bar" style="height:${Math.round(x.v / max * 78) + 3}px"></div>${['Pz', 'Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct'][x.d.getDay()]}</div>`).join('')}</div>

    <div class="sect">Dışa aktar</div>
    <button class="btn ghost" id="btnCsv" style="width:100%">📋 Bugünü panoya kopyala (CSV)</button>`;
  $('#btnShift').onclick = toggleShift;
  $('#btnQuick').onclick = () => { today().done.push({ id: uid(), title: 'Hızlı teslimat', fee: parseFloat($('#qf-fee').value) || 0, t: Date.now() }); saveHist(); renderEarn(); toast('+1 teslimat'); };
  $('#btnExp').onclick = () => { const a = parseFloat($('#ex-amt').value); if (!a) return toast('Tutar gir'); today().exp.push({ amt: a, note: $('#ex-note').value.trim(), t: Date.now() }); saveHist(); renderEarn(); toast('Gider eklendi'); };
  $('#btnCsv').onclick = async () => {
    const rows = ['Tarih,Saat,Baslik,Ucret', ...h.done.map(d => `${dayKey()},${fmtTime(d.t)},"${String(d.title).replace(/"/g, '""')}",${d.fee}`)];
    try { await navigator.clipboard.writeText(rows.join('\n')); toast('CSV panoya kopyalandı'); } catch { toast('Kopyalanamadı'); }
  };
}
function toggleShift() {
  if (S.shift.active) { today().ms += Date.now() - S.shift.since; S.shift = { active: false, since: 0 }; toast('Vardiya bitti'); }
  else { S.shift = { active: true, since: Date.now() }; toast('Vardiya başladı — iyi kazançlar! 🏍️'); wakeOn(); }
  saveShift(); saveHist(); renderEarn();
}
setInterval(() => { const el = $('#shiftTime'); if (el && $('#p-earn').classList.contains('on')) el.textContent = fmtHM(shiftMs()); }, 15000);

/* =====================================================================
   AYARLAR
   ===================================================================== */
function initSettings() {
  $$('[data-set]').forEach(el => {
    const k = el.dataset.set;
    if (el.type === 'checkbox') el.checked = !!S.settings[k]; else el.value = S.settings[k];
    el.addEventListener('change', () => {
      let v = el.type === 'checkbox' ? el.checked : el.type === 'number' ? (parseFloat(el.value) || 0) : el.value;
      if (k === 'cc') v = String(v).replace(/\D/g, '') || '90';
      S.settings[k] = v; saveSettings();
      if (k === 'theme') applyTheme();
      if (k === 'layer') setLayer(v);
      if (k === 'profile') refreshRoute();
      if (k === 'wake') { v ? wakeOn() : wakeOff(); }
      if (k === 'dwell') refreshRoute();
      if (['fee', 'cur', 'kmCost'].includes(k)) { renderEarn(); renderStops(); }
    });
  });
  $('#btnResetAll').onclick = () => {
    if (!confirm('Duraklar, kazanç geçmişi ve ayarlar silinsin mi?')) return;
    Object.keys(localStorage).filter(k => k.startsWith('kh_')).forEach(k => localStorage.removeItem(k));
    location.reload();
  };
}

/* =====================================================================
   ALT PANEL (sürükle / sekmeler)
   ===================================================================== */
const sheetEl = $('#sheet');
const COLLAPSED = 136;
const SNAP = () => [COLLAPSED, Math.round(innerHeight * 0.5), Math.round(innerHeight * 0.88)];
let sheetH = COLLAPSED;
function setSheet(h, animate = true) {
  sheetH = h;
  document.body.classList.toggle('dragging', !animate);
  document.documentElement.style.setProperty('--sheet-h', h + 'px');
  document.body.classList.toggle('sheet-big', h > innerHeight * 0.6);
}
setSheet(COLLAPSED);
(() => {
  const grab = $('#grab'); let y0 = 0, h0 = 0, dragging = false, moved = false, t0 = 0;
  grab.addEventListener('pointerdown', e => {
    if (e.target.closest('button')) return;
    dragging = true; moved = false; y0 = e.clientY; h0 = sheetH; t0 = Date.now(); grab.setPointerCapture(e.pointerId);
  });
  grab.addEventListener('pointermove', e => {
    if (!dragging) return;
    const dy = y0 - e.clientY; if (Math.abs(dy) > 4) moved = true;
    setSheet(clamp(h0 + dy, COLLAPSED, innerHeight * 0.9), false);
  });
  const end = e => {
    if (!dragging) return; dragging = false;
    const s = SNAP();
    if (!moved) { // dokunma: sıradaki seviyeye geç
      const i = s.findIndex(v => Math.abs(v - sheetH) < 20);
      setSheet(s[(i + 1) % s.length]); return;
    }
    const v = (y0 - e.clientY) / Math.max(1, Date.now() - t0); // px/ms
    let target = s.reduce((a, b) => Math.abs(b - sheetH) < Math.abs(a - sheetH) ? b : a);
    if (Math.abs(v) > 0.5) { const i = s.indexOf(target); target = s[clamp(i + (v > 0 ? 1 : -1), 0, s.length - 1)]; }
    setSheet(target);
  };
  grab.addEventListener('pointerup', end); grab.addEventListener('pointercancel', end);
})();
$('#tabs').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  $$('#tabs button').forEach(x => x.classList.toggle('on', x === b));
  $$('.panel').forEach(p => p.classList.toggle('on', p.id === 'p-' + b.dataset.tab));
  if (b.dataset.tab === 'earn') renderEarn();
  if (sheetH < innerHeight * 0.4) setSheet(SNAP()[1]);
});
addEventListener('resize', () => setSheet(clamp(sheetH, COLLAPSED, innerHeight * 0.9), false));

/* =====================================================================
   DÜĞMELER
   ===================================================================== */
$('#btnLocate').onclick = locateMe;
$('#btnFit').onclick = fitAll;
$('#btnLayers').onclick = () => { const ks = Object.keys(LAYERS); setLayer(ks[(ks.indexOf(S.settings.layer) + 1) % ks.length]); };
$('#btnOpt').onclick = optimizeOrder;
$('#btnRoute').onclick = () => { refreshRoute(); toast('Rota güncelleniyor…', 1200); };
$('#btnBulk').onclick = openBulk;
$('#btnGmaps').onclick = openAllGoogle;
$('#btnAdd').onclick = () => { body_pick(true); };
function body_pick(on) {
  document.body.classList.toggle('pick', on);
  $('#crosshair').hidden = !on; $('#pickbar').hidden = !on;
  if (on) { S.follow = false; $('#btnLocate').classList.remove('on'); setSheet(COLLAPSED); }
}
$('#pickCancel').onclick = () => body_pick(false);
$('#pickOk').onclick = () => { const c = map.getCenter(); body_pick(false); dropPoint(c.lat, c.lng); };

/* Android geri tuşu */
const appPlugin = plugin('App');
if (appPlugin && appPlugin.addListener) {
  appPlugin.addListener('backButton', () => {
    if (!$('#modal').hidden) return closeModal();
    if (document.body.classList.contains('pick')) return body_pick(false);
    if (sheetH > COLLAPSED + 10) return setSheet(COLLAPSED);
    if (appPlugin.minimizeApp) appPlugin.minimizeApp(); else if (appPlugin.exitApp) appPlugin.exitApp();
  });
}

/* servis çalışanı (çevrimdışı kabuk + harita önbelleği) */
if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
  addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => { }));
}

/* =====================================================================
   BAŞLAT
   ===================================================================== */
initSettings();
renderStops();
renderEarn();
if (pend().length && !S.me && S.settings.autoRoute) scheduleRoute();
startGPS();
wakeOn();
loadWeather();
})();
