# 🏍️ Kurye Harita

Kuryeler için HTML5 harita uygulaması. Leaflet + OpenStreetMap üzerine kurulu; **hiçbir API anahtarı veya ücretli servis gerektirmez**. Capacitor ile APK'ya çevrilir.

## Özellikler

| Özellik | Nasıl çalışır |
|---|---|
| 📍 Canlı konum | GPS, takip modu, hız göstergesi, yön oku |
| 🔍 Adres arama | Nominatim (yedek: Photon) |
| 📦 Durak yönetimi | Arama, haritaya uzun basma, ＋ ile hedef seçme, **toplu adres yapıştırma** |
| 🔀 Rota optimizasyonu | En yakın komşu + 2-opt, konumundan başlar |
| 🛣️ Gerçek yol rotası | OSRM (motosiklet/araba, bisiklet, yaya), ETA ve toplam süre |
| 🧭 Navigasyon | Google Haritalar / Yandex Navigasyon / Waze / geo: — tek dokunuş |
| 📞 Müşteri | Ara, WhatsApp, kapı kodu/kat notu |
| ⛽ Yakındaki yerler | Benzinlik, tamirci, WC, yemek, eczane, ATM, şarj (Overpass) |
| 🌧️ Hava | Open-Meteo: yağmur, rüzgâr, buzlanma, sıcak uyarısı + gün batımı |
| 💰 Kazanç takibi | Teslimat, brüt/net, km, saatlik kazanç, gider, 7 günlük grafik |
| 🌙 Koyu tema, 4 harita türü, ekranı açık tut, çevrimdışı kabuk + karo önbelleği | |

Veriler yalnızca telefonda (localStorage) saklanır, sunucuya gitmez.

## Bilgisayarda deneme

```bash
npm install
npm run serve        # http://localhost:8080
```

(Konum için tarayıcı izni gerekir; `localhost` güvenli sayılır.)

## APK oluşturma

### Yol 1 — Bilgisayarsız, GitHub ile (en kolayı)

1. GitHub'da yeni bir depo aç, bu klasörün **tüm içeriğini** yükle (`.github` klasörü dahil).
2. Depoda **Actions → APK Derle → Run workflow**.
3. 4–6 dk sonra çıkan **kurye-harita-apk** dosyasını indir, zip'ten çıkan `app-debug.apk`'yı telefona kur.

### Yol 2 — Android Studio ile

Gerekenler: Node 20+, JDK 21, Android Studio.

```bash
npm install
npx cap add android
npm run icons          # resources/icon.png → uygulama simgesi
npx cap sync android
npx cap open android   # Build → Build APK(s)
```

veya komut satırından: `npm run apk` → `android/app/build/outputs/apk/debug/app-debug.apk`

### Yol 3 — PWA (APK'sız)

`www/` klasörünü herhangi bir HTTPS sunucuya (GitHub Pages, Netlify, Cloudflare Pages) yükle, telefonda Chrome'dan aç → "Ana ekrana ekle".

## Önemli notlar

- **Konum izni**: `@capacitor/geolocation` eklentisi gerekli izinleri APK'ya kendisi ekler.
- **Harita karoları**: `tile.openstreetmap.org` kişisel/hafif kullanım içindir. Çok sayıda kullanıcıya dağıtacaksan `app.js` içindeki `LAYERS` bölümünde CARTO'yu (varsayılan) kullan veya MapTiler/Stadia gibi ücretsiz kotalı bir sağlayıcıya anahtar ekle.
- **Arama/rota sunucuları** halka açık, ücretsiz demo sunuculardır; limitleri vardır (Nominatim: saniyede 1 istek — toplu ekleme bunu otomatik uygular). Ağır kullanımda kendi OSRM/Nominatim sunucunu kurmak veya ücretli plana geçmek gerekir.
- **Rota optimizasyonu** kuş uçuşu mesafeyle çalışır; yol ağına göre kesin en kısa sıra garantisi vermez ama genelde çok iyi sonuç verir. Gerekirse ▲▼ ile elle düzelt.
- **Arka plan konumu**: Uygulama açıkken (ekran açık) km sayımı yapar. Ekran kapalıyken sayım için arka plan konum eklentisi gerekir (Google Play politikası gerektirir).
- Release (Play Store) APK/AAB için imzalama anahtarı oluşturmalısın; debug APK doğrudan telefona kurmak için yeterlidir.

## Dosya yapısı

```
www/            uygulama (index.html, app.js, style.css, sw.js, manifest.json, lib/leaflet)
resources/      icon.png (APK simgesi kaynağı)
capacitor.config.json
.github/workflows/build-apk.yml
```
